import "./styles/main.css";
import "./scripts/main.js";

console.log("Aplikasi Notes App dimulai");
